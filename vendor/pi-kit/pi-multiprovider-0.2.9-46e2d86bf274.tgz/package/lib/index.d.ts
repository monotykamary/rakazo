import { Api, AssistantMessage, AuthResult, Context, Credential, Model, Provider, ProviderAuth, StreamOptions } from "@earendil-works/pi-ai";
import { ExtensionAPI } from "@earendil-works/pi-coding-agent";
//#region src/types.d.ts
type AuthKind = 'api-key' | 'oauth' | 'service-account' | 'custom';
type SelectionPolicy = 'round-robin' | 'weighted-round-robin' | 'least-inflight' | 'priority';
type FailureKind = 'rate-limit' | 'quota' | 'auth' | 'transient' | 'fatal';
interface ProviderAttemptFailure {
  message: string;
  status?: number;
  headers?: Readonly<Record<string, string>>;
  assistantMessage?: AssistantMessage;
  cause?: unknown;
  outputStarted: boolean;
}
interface ProviderAccount<TCredentialRef = unknown> {
  id: string;
  label: string;
  authKind: AuthKind;
  credentialRef: TCredentialRef;
  enabled?: boolean;
  weight?: number;
  priority?: number;
  metadata?: Readonly<Record<string, string | number | boolean | null>>;
}
interface FailureDisposition {
  kind: FailureKind;
  retryable: boolean;
  cooldownMs?: number;
}
interface ProviderRegistration<TCredentialRef = unknown> {
  id: string;
  label: string;
  accounts: () => readonly ProviderAccount<TCredentialRef>[] | Promise<readonly ProviderAccount<TCredentialRef>[]>;
  classifyFailure?: (failure: ProviderAttemptFailure, account: ProviderAccount<TCredentialRef>) => FailureDisposition;
  managementHint?: string;
}
interface AccountPreference {
  accountId: string;
  enabled: boolean;
  weight: number;
  priority: number;
}
interface PoolPreference {
  providerId: string;
  policy: SelectionPolicy;
  affinity: boolean;
  accounts: AccountPreference[];
}
interface AcquireOptions {
  providerId: string;
  affinityKey?: string;
  excludeAccountIds?: Iterable<string>;
}
interface LeaseOutcomeSuccess {
  status: 'success';
}
interface LeaseOutcomeFailure {
  status: 'failure';
  error: ProviderAttemptFailure;
}
interface LeaseOutcomeCancelled {
  status: 'cancelled';
}
type LeaseOutcome = LeaseOutcomeSuccess | LeaseOutcomeFailure | LeaseOutcomeCancelled;
interface AccountLease<TCredentialRef = unknown> {
  readonly id: string;
  readonly providerId: string;
  readonly accountId: string;
  readonly account: ProviderAccount<TCredentialRef>;
  readonly credentialRef: TCredentialRef;
  readonly acquiredAt: number;
  release(outcome?: LeaseOutcome): FailureDisposition | undefined;
}
type PublicAccountStatus = 'ready' | 'cooldown' | 'disabled';
interface PublicAccountSnapshot {
  id: string;
  label: string;
  authKind: AuthKind;
  enabled: boolean;
  weight: number;
  priority: number;
  status: PublicAccountStatus;
  inFlight: number;
  consecutiveFailures: number;
  cooldownUntil?: number;
  lastSelectedAt?: number;
  lastFailureKind?: FailureKind;
  metadata: Readonly<Record<string, string | number | boolean | null>>;
}
interface PublicPoolSnapshot {
  id: string;
  label: string;
  policy: SelectionPolicy;
  affinity: boolean;
  managementHint?: string;
  accounts: PublicAccountSnapshot[];
}
interface MultiProviderSnapshot {
  providers: PublicPoolSnapshot[];
}
interface SchedulerSettings {
  rateLimitCooldownMs?: number;
  quotaCooldownMs?: number;
  authCooldownMs?: number;
  transientBaseCooldownMs?: number;
  maxCooldownMs?: number;
}
type SchedulerSettingsPatch = { [K in keyof SchedulerSettings]?: SchedulerSettings[K] | undefined; };
declare const SCHEDULER_SETTING_KEYS: readonly ["rateLimitCooldownMs", "quotaCooldownMs", "authCooldownMs", "transientBaseCooldownMs", "maxCooldownMs"];
interface SchedulerOptions {
  defaultPolicy?: SelectionPolicy;
  affinity?: boolean;
  rateLimitCooldownMs?: number;
  quotaCooldownMs?: number;
  authCooldownMs?: number;
  transientBaseCooldownMs?: number;
  maxCooldownMs?: number;
  now?: () => number;
  randomId?: () => string;
}
interface AccountRequestContext<TApi extends Api = Api> {
  provider: Provider<TApi>;
  model: Model<TApi>;
  context: Context;
  requestOptions: Readonly<StreamOptions & Record<string, unknown>>;
  signal: AbortSignal;
}
interface AccountAttemptContext<TApi extends Api = Api, TCredentialRef = unknown> extends AccountRequestContext<TApi> {
  account: ProviderAccount<TCredentialRef>;
  resolution: AuthResult;
}
interface LiftProviderOptions<TApi extends Api = Api, TCredentialRef = unknown> {
  auth?: ProviderAuth;
  resolveAuth: (account: ProviderAccount<TCredentialRef>, signal: AbortSignal, request: AccountRequestContext<TApi>) => AuthResult | Promise<AuthResult>;
  excludeAccountIds?: (request: AccountRequestContext<TApi>) => Iterable<string> | Promise<Iterable<string>>;
  sanitizeRequestOptions?: (attempt: AccountAttemptContext<TApi, TCredentialRef>) => StreamOptions & Record<string, unknown>;
  affinityKey?: (input: {
    provider: Provider<TApi>;
    model: Model<TApi>;
    context: Context;
  }) => string | undefined;
  disableProviderRetries?: boolean;
  maxAccountAttempts?: number;
}
interface MultiProviderIntegration<TApi extends Api = Api, TCredentialRef = unknown> extends ProviderRegistration<TCredentialRef>, LiftProviderOptions<TApi, TCredentialRef> {}
declare const MULTIPROVIDER_REGISTER_EVENT = "pi-multiprovider:register";
//#endregion
//#region src/errors.d.ts
declare class UnknownProviderError extends Error {
  readonly providerId: string;
  constructor(providerId: string);
}
declare class NoAccountAvailableError extends Error {
  readonly providerId: string;
  readonly nextAvailableAt?: number | undefined;
  constructor(providerId: string, nextAvailableAt?: number | undefined);
}
//#endregion
//#region src/service.d.ts
declare const SCHEDULER_DEFAULTS: Required<SchedulerSettings>;
declare class MultiProviderService {
  private readonly providers;
  private readonly preferences;
  private readonly runtime;
  private readonly affinity;
  private readonly roundRobinCursor;
  private readonly smoothScores;
  private readonly defaults;
  private readonly now;
  private readonly randomId;
  constructor(options?: SchedulerOptions);
  registerProvider<TCredentialRef>(registration: ProviderRegistration<TCredentialRef>): () => void;
  hasProvider(providerId: string): boolean;
  hasEnabledAccounts(providerId: string): Promise<boolean>;
  acquire<TCredentialRef = unknown>(options: AcquireOptions): Promise<AccountLease<TCredentialRef>>;
  snapshot(): Promise<MultiProviderSnapshot>;
  updatePool(providerId: string, patch: Partial<Pick<PoolPreference, 'policy' | 'affinity' | 'accounts'>>): Promise<PublicPoolSnapshot>;
  getPoolPreference(providerId: string): PoolPreference;
  updateSchedulerDefaults(settings: SchedulerSettings): void;
  resetHealth(providerId: string, accountId: string): void;
  clearAffinity(providerId?: string, affinityKey?: string): void;
  private registration;
  private pool;
  private runtimeFor;
  private effectiveAccounts;
  private select;
  private selectWeighted;
  private recordSuccess;
  private recordFailure;
  private defaultCooldown;
}
//#endregion
//#region src/lift.d.ts
declare function liftProvider<TApi extends Api, TCredentialRef = unknown>(provider: Provider<TApi>, service: MultiProviderService, options: LiftProviderOptions<TApi, TCredentialRef>): Provider<TApi>;
//#endregion
//#region src/register.d.ts
declare function registerMultiProvider<TApi extends Api, TCredentialRef>(pi: ExtensionAPI, integration: MultiProviderIntegration<TApi, TCredentialRef>): void;
//#endregion
//#region src/auth-store.d.ts
declare const MULTIPROVIDER_AUTH_FILE = "multiprovider-auth.json";
interface MultiAuthAccount {
  id: string;
  label: string;
  authKind: AuthKind;
  enabled: boolean;
  weight: number;
  priority: number;
  createdAt: string;
  updatedAt: string;
}
interface MultiAuthUpstreamPreferences {
  label?: string;
  weight?: number;
  priority?: number;
}
interface MultiAuthPool {
  providerId: string;
  policy: SelectionPolicy;
  affinity: boolean;
  includeUpstream: boolean;
  upstream?: MultiAuthUpstreamPreferences;
  accounts: MultiAuthAccount[];
}
interface AddMultiAuthAccount {
  label: string;
  credential: Credential;
  enabled?: boolean;
  weight?: number;
  priority?: number;
  pool?: MultiAuthPoolSettings;
}
interface MultiAuthPoolSettings {
  policy?: SelectionPolicy;
  affinity?: boolean;
  includeUpstream?: boolean;
  upstream?: MultiAuthUpstreamPreferences;
}
interface MultiAuthAccountSettings {
  label?: string;
  enabled?: boolean;
  weight?: number;
  priority?: number;
}
declare function normalizeUpstreamPreferences(input: MultiAuthUpstreamPreferences): MultiAuthUpstreamPreferences;
declare function getMultiAuthPath(): string;
declare class MultiAuthStore {
  readonly path: string;
  private readonly lockPath;
  constructor(path?: string);
  listProviderIds(): Promise<string[]>;
  getPool(providerId: string): Promise<MultiAuthPool | undefined>;
  hasAccounts(providerId: string): Promise<boolean>;
  addAccount(providerId: string, input: AddMultiAuthAccount): Promise<MultiAuthAccount>;
  removeAccount(providerId: string, accountId: string): Promise<boolean>;
  updatePool(providerId: string, settings: MultiAuthPoolSettings): Promise<MultiAuthPool>;
  updateAccount(providerId: string, accountId: string, settings: MultiAuthAccountSettings): Promise<MultiAuthAccount>;
  getSchedulerSettings(): Promise<SchedulerSettings>;
  updateSchedulerSettings(settings: SchedulerSettingsPatch): Promise<SchedulerSettings>;
  resolveAccount<TApi extends Api>(provider: Provider<TApi>, accountId: string, signal: AbortSignal): Promise<AuthResult>;
  private mutate;
  private readState;
  private readStateUnlocked;
  private writeStateUnlocked;
  private withLock;
}
//#endregion
//#region src/managed.d.ts
declare const PI_UPSTREAM_ACCOUNT_ID = "pi:default";
declare function mergeProviderAuth(provider: Provider<Api>, hasStoredAccounts: () => Promise<boolean>): ProviderAuth;
declare function createManagedIntegration<TApi extends Api>(provider: Provider<TApi>, store: MultiAuthStore): MultiProviderIntegration<TApi, string>;
//#endregion
export { AccountAttemptContext, AccountLease, AccountPreference, AccountRequestContext, AcquireOptions, AddMultiAuthAccount, AuthKind, FailureDisposition, FailureKind, LeaseOutcome, LeaseOutcomeCancelled, LeaseOutcomeFailure, LeaseOutcomeSuccess, LiftProviderOptions, MULTIPROVIDER_AUTH_FILE, MULTIPROVIDER_REGISTER_EVENT, MultiAuthAccount, MultiAuthAccountSettings, MultiAuthPool, MultiAuthPoolSettings, MultiAuthStore, MultiAuthUpstreamPreferences, MultiProviderIntegration, MultiProviderService, MultiProviderSnapshot, NoAccountAvailableError, PI_UPSTREAM_ACCOUNT_ID, PoolPreference, ProviderAccount, ProviderAttemptFailure, ProviderRegistration, PublicAccountSnapshot, PublicAccountStatus, PublicPoolSnapshot, SCHEDULER_DEFAULTS, SCHEDULER_SETTING_KEYS, SchedulerOptions, SchedulerSettings, SchedulerSettingsPatch, SelectionPolicy, UnknownProviderError, createManagedIntegration, getMultiAuthPath, liftProvider, mergeProviderAuth, normalizeUpstreamPreferences, registerMultiProvider };