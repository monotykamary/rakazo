import { Api, AssistantMessage, AuthResult, Credential, Model, Provider, ProviderAuth, ProviderHeaders, StreamOptions, TranscriptContext } from "@earendil-works/pi-ai";
import { ExtensionAPI, ExtensionContext } from "@earendil-works/pi-coding-agent";
//#region src/types.d.ts
type AuthKind = 'api-key' | 'oauth' | 'service-account' | 'custom';
type SelectionPolicy = 'round-robin' | 'weighted-round-robin' | 'least-inflight' | 'priority';
type FailureKind = 'rate-limit' | 'quota' | 'auth' | 'transient' | 'fatal';
type SelectionBias = 'first-account' | 'none';
interface ProviderAttemptFailure {
  message: string;
  status?: number;
  headers?: Readonly<Record<string, string>>;
  assistantMessage?: AssistantMessage;
  cause?: unknown;
  outputStarted: boolean;
}
interface ProviderAccount<TCredentialRef = unknown> {
  id: string;
  label: string;
  authKind: AuthKind;
  credentialRef: TCredentialRef;
  enabled?: boolean;
  weight?: number;
  priority?: number;
  metadata?: Readonly<Record<string, string | number | boolean | null>>;
}
interface FailureDisposition {
  kind: FailureKind;
  retryable: boolean;
  cooldownMs?: number;
}
interface ProviderRegistration<TCredentialRef = unknown> {
  id: string;
  label: string;
  accounts: () => readonly ProviderAccount<TCredentialRef>[] | Promise<readonly ProviderAccount<TCredentialRef>[]>;
  classifyFailure?: (failure: ProviderAttemptFailure, account: ProviderAccount<TCredentialRef>) => FailureDisposition | undefined;
  managementHint?: string;
  selectionBias?: SelectionBias;
}
interface AccountPreference {
  accountId: string;
  enabled: boolean;
  weight: number;
  priority: number;
}
interface PoolPreference {
  providerId: string;
  policy: SelectionPolicy;
  affinity: boolean;
  accounts: AccountPreference[];
}
interface AffinityPin {
  accountId: string;
  explicit: boolean;
}
interface AcquireOptions {
  providerId: string;
  affinityKey?: string;
  excludeAccountIds?: Iterable<string>;
}
interface LeaseOutcomeSuccess {
  status: 'success';
}
interface LeaseOutcomeFailure {
  status: 'failure';
  error: ProviderAttemptFailure;
}
interface LeaseOutcomeCancelled {
  status: 'cancelled';
}
type LeaseOutcome = LeaseOutcomeSuccess | LeaseOutcomeFailure | LeaseOutcomeCancelled;
interface AccountLease<TCredentialRef = unknown> {
  readonly id: string;
  readonly providerId: string;
  readonly accountId: string;
  readonly account: ProviderAccount<TCredentialRef>;
  readonly credentialRef: TCredentialRef;
  readonly acquiredAt: number;
  release(outcome?: LeaseOutcome): FailureDisposition | undefined;
}
type PublicAccountStatus = 'ready' | 'cooldown' | 'disabled';
interface PublicAccountSnapshot {
  id: string;
  label: string;
  authKind: AuthKind;
  enabled: boolean;
  weight: number;
  priority: number;
  status: PublicAccountStatus;
  inFlight: number;
  consecutiveFailures: number;
  cooldownUntil?: number;
  lastSelectedAt?: number;
  lastFailureKind?: FailureKind;
  metadata: Readonly<Record<string, string | number | boolean | null>>;
}
interface PublicPoolSnapshot {
  id: string;
  label: string;
  policy: SelectionPolicy;
  affinity: boolean;
  firstAccountBias: boolean;
  managementHint?: string;
  accounts: PublicAccountSnapshot[];
}
interface MultiProviderSnapshot {
  providers: PublicPoolSnapshot[];
}
/**
 * Fired when a pooled account is abandoned after its final tolerated error
 * and the stream is about to move to another account. Returning true tells
 * the stream to surface the buffered error instead of rotating accounts
 * inline — an external handler (e.g. compact-then-retry) will re-enter the
 * pool with fresh context.
 */
interface FailoverInfo {
  providerId: string;
  fromAccountId: string;
  failure: ProviderAttemptFailure;
  errorsOnAccount: number;
}
interface SchedulerSettings {
  rateLimitCooldownMs?: number;
  quotaCooldownMs?: number;
  authCooldownMs?: number;
  transientBaseCooldownMs?: number;
  maxCooldownMs?: number;
  errorsBeforeSwitch?: number;
}
type SchedulerSettingsPatch = { [K in keyof SchedulerSettings]?: SchedulerSettings[K] | undefined; };
interface VirtualModelTemplate {
  api: Model<Api>['api'];
  baseUrl: string;
  reasoning: boolean;
  thinkingLevelMap?: Model<Api>['thinkingLevelMap'];
  input: Model<Api>['input'];
  cost: Model<Api>['cost'];
  contextWindow: number;
  maxTokens: number;
}
interface VirtualBackend {
  providerId: string;
  modelId: string;
  enabled?: boolean;
  weight?: number;
  template?: VirtualModelTemplate;
}
interface VirtualModelConfig {
  id: string;
  label?: string;
  backends: VirtualBackend[];
}
interface VirtualProviderConfig {
  id: string;
  label: string;
  models: VirtualModelConfig[];
}
declare const SCHEDULER_SETTING_KEYS: readonly ["rateLimitCooldownMs", "quotaCooldownMs", "authCooldownMs", "transientBaseCooldownMs", "maxCooldownMs", "errorsBeforeSwitch"];
interface SchedulerOptions {
  defaultPolicy?: SelectionPolicy;
  affinity?: boolean;
  rateLimitCooldownMs?: number;
  quotaCooldownMs?: number;
  authCooldownMs?: number;
  transientBaseCooldownMs?: number;
  maxCooldownMs?: number;
  errorsBeforeSwitch?: number;
  now?: () => number;
  randomId?: () => string;
  randomInt?: (maxExclusive: number) => number;
}
interface AccountRequestContext<TApi extends Api = Api> {
  provider: Provider<TApi>;
  model: Model<TApi>;
  context: TranscriptContext;
  requestOptions: Readonly<StreamOptions & Record<string, unknown>>;
  signal: AbortSignal;
}
interface AccountAttemptContext<TApi extends Api = Api, TCredentialRef = unknown> extends AccountRequestContext<TApi> {
  account: ProviderAccount<TCredentialRef>;
  resolution: AuthResult;
}
interface LiftProviderOptions<TApi extends Api = Api, TCredentialRef = unknown> {
  auth?: ProviderAuth;
  resolveAuth: (account: ProviderAccount<TCredentialRef>, signal: AbortSignal, request: AccountRequestContext<TApi>) => AuthResult | Promise<AuthResult>;
  excludeAccountIds?: (request: AccountRequestContext<TApi>) => Iterable<string> | Promise<Iterable<string>>;
  sanitizeRequestOptions?: (attempt: AccountAttemptContext<TApi, TCredentialRef>) => StreamOptions & Record<string, unknown>;
  affinityKey?: (input: {
    provider: Provider<TApi>;
    model: Model<TApi>;
    context: TranscriptContext;
  }) => string | undefined;
  disableProviderRetries?: boolean;
  maxAccountAttempts?: number;
  onFailover?: (info: FailoverInfo) => boolean | void;
}
interface MultiProviderIntegration<TApi extends Api = Api, TCredentialRef = unknown> extends ProviderRegistration<TCredentialRef>, LiftProviderOptions<TApi, TCredentialRef> {}
declare const MULTIPROVIDER_REGISTER_EVENT = "pi-multiprovider:register";
declare const MULTIPROVIDER_SERVICE_EVENT = "pi-multiprovider:service";
type MultiProviderServiceContext = Pick<ExtensionContext, 'modelRegistry' | 'model' | 'sessionManager'>;
interface ActiveAccount {
  id: string;
  label: string;
  authKind: AuthKind;
}
interface ActiveAccountAuth {
  accessToken: string;
  label: string;
  source?: string;
}
interface ActiveAccountChangedEvent {
  providerId: string;
  account: ActiveAccount | undefined;
  ctx: ExtensionContext;
}
interface MultiProviderServiceAnnouncement {
  getActiveAccount(providerId: string, ctx: MultiProviderServiceContext): Promise<ActiveAccount | undefined>;
  resolveActiveAccountAuth(providerId: string, ctx: MultiProviderServiceContext, signal?: AbortSignal): Promise<ActiveAccountAuth | undefined>;
  onActiveAccountChanged(providerId: string, callback: (event: ActiveAccountChangedEvent) => void): () => void;
}
//#endregion
//#region src/errors.d.ts
declare class UnknownProviderError extends Error {
  readonly providerId: string;
  constructor(providerId: string);
}
declare class UnknownAccountError extends Error {
  readonly providerId: string;
  readonly accountId: string;
  constructor(providerId: string, accountId: string);
}
declare class NoAccountAvailableError extends Error {
  readonly providerId: string;
  readonly nextAvailableAt?: number | undefined;
  constructor(providerId: string, nextAvailableAt?: number | undefined);
}
//#endregion
//#region src/service.d.ts
declare const SCHEDULER_DEFAULTS: Required<SchedulerSettings>;
declare class MultiProviderService {
  private readonly providers;
  private readonly preferences;
  private readonly runtime;
  private readonly selectionBias;
  private readonly affinity;
  private readonly explicitAffinity;
  private readonly roundRobinCursor;
  private readonly smoothScores;
  private readonly defaults;
  private readonly now;
  private readonly randomId;
  private readonly randomInt;
  constructor(options?: SchedulerOptions);
  registerProvider<TCredentialRef>(registration: ProviderRegistration<TCredentialRef>): () => void;
  hasProvider(providerId: string): boolean;
  hasEnabledAccounts(providerId: string): Promise<boolean>;
  acquire<TCredentialRef = unknown>(options: AcquireOptions): Promise<AccountLease<TCredentialRef>>;
  snapshot(): Promise<MultiProviderSnapshot>;
  updatePool(providerId: string, patch: Partial<Pick<PoolPreference, 'policy' | 'affinity' | 'accounts'>>): Promise<PublicPoolSnapshot>;
  getPoolPreference(providerId: string): PoolPreference;
  getErrorsBeforeSwitch(): number;
  updateSchedulerDefaults(settings: SchedulerSettings): void;
  resetHealth(providerId: string, accountId: string): void;
  pinAccount(providerId: string, affinityKey: string, accountId: string): Promise<void>;
  getAffinity(providerId: string, affinityKey: string): AffinityPin | undefined;
  clearAffinity(providerId?: string, affinityKey?: string): void;
  private registration;
  private pool;
  private runtimeFor;
  private effectiveAccounts;
  private select;
  private selectWeighted;
  private recordSuccess;
  private recordFailure;
  private defaultCooldown;
}
//#endregion
//#region src/lift.d.ts
declare function liftProvider<TApi extends Api, TCredentialRef = unknown>(provider: Provider<TApi>, service: MultiProviderService, options: LiftProviderOptions<TApi, TCredentialRef>): Provider<TApi>;
//#endregion
//#region src/virtual.d.ts
declare const VIRTUAL_ID_SEPARATOR = "::";
declare const BACKEND_UNAVAILABLE_PREFIX = "multiprovider: virtual backend unavailable";
declare function virtualSchedulerId(virtualProviderId: string, modelId: string): string;
declare function virtualBackendAccountId(backend: Pick<VirtualBackend, 'providerId' | 'modelId'>): string;
type AmbientAuthResolution = {
  ok: true;
  apiKey?: string;
  headers?: ProviderHeaders;
  baseUrl?: string;
  env?: Record<string, string>;
} | {
  ok: false;
  error: string;
};
interface VirtualProviderDependencies {
  service: MultiProviderService;
  config: VirtualProviderConfig;
  getAffinityKey: () => string;
  getBackingProvider: (providerId: string) => Provider<Api> | undefined;
  resolveAmbientAuth: (providerId: string, model: Model<Api>, signal: AbortSignal) => Promise<AmbientAuthResolution>;
  isBackendConfigured?: (providerId: string) => boolean;
  maxAccountAttempts?: number;
  onFailover?: (info: FailoverInfo) => boolean | void;
}
interface VirtualIntegrationOptions {
  getProviderLabel?: (providerId: string) => string | undefined;
  maxAccountAttempts?: number;
}
declare function createVirtualIntegrations(config: VirtualProviderConfig, options?: VirtualIntegrationOptions): ProviderRegistration<VirtualBackend>[];
declare function captureVirtualModelTemplate(model: Model<Api>): VirtualModelTemplate;
declare function healVirtualTemplates(config: VirtualProviderConfig, resolveTemplate: (providerId: string, modelId: string) => VirtualModelTemplate | undefined): VirtualProviderConfig | undefined;
declare function createVirtualProvider(dependencies: VirtualProviderDependencies): Provider<Api>;
//#endregion
//#region src/announcement.d.ts
interface AnnouncementDependencies {
  scheduler: MultiProviderService;
  getIntegration(providerId: string): MultiProviderIntegration<Api, unknown> | undefined;
  getBaseProvider(providerId: string, ctx: MultiProviderServiceContext): Provider<Api> | undefined;
  affinityKeyFor(integration: MultiProviderIntegration<Api, unknown>, ctx: MultiProviderServiceContext, providerId: string): string;
}
interface ServiceAnnouncementHandle extends MultiProviderServiceAnnouncement {
  notifyActiveAccountChanged(providerId: string, ctx: ExtensionContext, account: ActiveAccount | undefined): void;
}
declare function createServiceAnnouncement(deps: AnnouncementDependencies): ServiceAnnouncementHandle;
//#endregion
//#region src/register.d.ts
declare function registerMultiProvider<TApi extends Api, TCredentialRef>(pi: ExtensionAPI, integration: MultiProviderIntegration<TApi, TCredentialRef>): void;
//#endregion
//#region src/session-pins.d.ts
declare const SESSION_PIN_ENTRY_TYPE = "pi-multiprovider:switch-account";
declare const SESSION_PIN_ENV = "PI_MULTIPROVIDER_SESSION_PINS";
/** One /switch-account decision: the account pinned to one session pool. */
interface SessionPin {
  pool: string;
  key: string;
  /** Pinned account; undefined records an explicit return to automatic selection. */
  accountId?: string;
  /** Account label at switch time, used only to describe restore failures. */
  label?: string;
}
/** Parent /switch-account decision rebound onto a child session. */
interface InheritedSessionPin {
  pool: string;
  accountId?: string;
  label?: string;
}
interface SessionPinHost {
  /** Whether the pool's scheduler is registered yet. */
  hasPool(pool: string): boolean;
  pin(pool: string, key: string, accountId: string): void | Promise<void>;
  clear(pool: string, key: string): void;
}
/**
 * Reads the session's custom entries and returns the latest decision per pool
 * and affinity key, in the order the pools were first decided. Entries written
 * by other extensions, malformed records, and superseded decisions are ignored.
 */
declare function sessionPinsFromEntries(entries: Iterable<unknown>): SessionPin[];
/**
 * Replays recorded decisions into the scheduler. Pools whose scheduler is not
 * registered yet are returned so the caller can retry after the next
 * reconcile; stale records — a removed or disabled account — are reported to
 * onError and dropped so they never block a later pin. Decisions that reached
 * the scheduler are reported to onApplied, which is how a resume tells
 * followers of the session's active account that it changed.
 */
declare function applySessionPins(pins: readonly SessionPin[], host: SessionPinHost, onError?: (pin: SessionPin, error: unknown) => void, onApplied?: (pin: SessionPin) => void): Promise<SessionPin[]>;
/** Latest inherited pin per pool. Foreign, malformed, and empty records are dropped. */
declare function inheritedSessionPinsFromUnknown(value: unknown): InheritedSessionPin[];
declare function inheritedSessionPinsFromEnv(env?: NodeJS.ProcessEnv): InheritedSessionPin[];
declare function serializeInheritedSessionPins(pins: readonly InheritedSessionPin[]): string;
//#endregion
//#region src/auth-store.d.ts
declare const MULTIPROVIDER_AUTH_FILE = "multiprovider-auth.json";
interface MultiAuthAccount {
  id: string;
  label: string;
  authKind: AuthKind;
  enabled: boolean;
  weight: number;
  priority: number;
  createdAt: string;
  updatedAt: string;
}
interface MultiAuthUpstreamPreferences {
  label?: string;
  weight?: number;
  priority?: number;
}
interface MultiAuthPool {
  providerId: string;
  policy: SelectionPolicy;
  affinity: boolean;
  includeUpstream: boolean;
  upstream?: MultiAuthUpstreamPreferences;
  accounts: MultiAuthAccount[];
}
interface AddMultiAuthAccount {
  label: string;
  credential: Credential;
  enabled?: boolean;
  weight?: number;
  priority?: number;
  pool?: MultiAuthPoolSettings;
}
interface MultiAuthPoolSettings {
  policy?: SelectionPolicy;
  affinity?: boolean;
  includeUpstream?: boolean;
  upstream?: MultiAuthUpstreamPreferences;
}
interface MultiAuthAccountSettings {
  label?: string;
  enabled?: boolean;
  weight?: number;
  priority?: number;
}
declare function normalizeUpstreamPreferences(input: MultiAuthUpstreamPreferences): MultiAuthUpstreamPreferences;
declare function getMultiAuthPath(): string;
declare class MultiAuthStore {
  readonly path: string;
  private readonly lockPath;
  constructor(path?: string);
  listProviderIds(): Promise<string[]>;
  getPool(providerId: string): Promise<MultiAuthPool | undefined>;
  hasAccounts(providerId: string): Promise<boolean>;
  addAccount(providerId: string, input: AddMultiAuthAccount): Promise<MultiAuthAccount>;
  /**
   * Replaces an existing account's credential in place. Reauthentication uses
   * this instead of remove + add so the account keeps its id, label, weight,
   * priority, and any session pins pointing at it.
   */
  replaceAccountCredential(providerId: string, accountId: string, credential: Credential): Promise<MultiAuthAccount>;
  removeAccount(providerId: string, accountId: string): Promise<boolean>;
  updatePool(providerId: string, settings: MultiAuthPoolSettings): Promise<MultiAuthPool>;
  updateAccount(providerId: string, accountId: string, settings: MultiAuthAccountSettings): Promise<MultiAuthAccount>;
  getSchedulerSettings(): Promise<SchedulerSettings>;
  updateSchedulerSettings(settings: SchedulerSettingsPatch): Promise<SchedulerSettings>;
  listVirtualProviders(): Promise<VirtualProviderConfig[]>;
  getVirtualProvider(id: string): Promise<VirtualProviderConfig | undefined>;
  saveVirtualProvider(input: VirtualProviderConfig): Promise<VirtualProviderConfig>;
  removeVirtualProvider(id: string): Promise<boolean>;
  resolveAccount<TApi extends Api>(provider: Provider<TApi>, accountId: string, signal: AbortSignal): Promise<AuthResult>;
  private mutate;
  private readState;
  private readStateUnlocked;
  private writeStateUnlocked;
  private withLock;
}
//#endregion
//#region src/managed.d.ts
declare const PI_UPSTREAM_ACCOUNT_ID = "pi:default";
declare function mergeProviderAuth(provider: Provider<Api>, hasStoredAccounts: () => Promise<boolean>): ProviderAuth;
declare function createManagedIntegration<TApi extends Api>(provider: Provider<TApi>, store: MultiAuthStore): MultiProviderIntegration<TApi, string>;
//#endregion
export { AccountAttemptContext, AccountLease, AccountPreference, AccountRequestContext, AcquireOptions, ActiveAccount, ActiveAccountAuth, ActiveAccountChangedEvent, AddMultiAuthAccount, AffinityPin, type AmbientAuthResolution, type AnnouncementDependencies, AuthKind, BACKEND_UNAVAILABLE_PREFIX, FailoverInfo, FailureDisposition, FailureKind, type InheritedSessionPin, LeaseOutcome, LeaseOutcomeCancelled, LeaseOutcomeFailure, LeaseOutcomeSuccess, LiftProviderOptions, MULTIPROVIDER_AUTH_FILE, MULTIPROVIDER_REGISTER_EVENT, MULTIPROVIDER_SERVICE_EVENT, MultiAuthAccount, MultiAuthAccountSettings, MultiAuthPool, MultiAuthPoolSettings, MultiAuthStore, MultiAuthUpstreamPreferences, MultiProviderIntegration, MultiProviderService, MultiProviderServiceAnnouncement, MultiProviderServiceContext, MultiProviderSnapshot, NoAccountAvailableError, PI_UPSTREAM_ACCOUNT_ID, PoolPreference, ProviderAccount, ProviderAttemptFailure, ProviderRegistration, PublicAccountSnapshot, PublicAccountStatus, PublicPoolSnapshot, SCHEDULER_DEFAULTS, SCHEDULER_SETTING_KEYS, SESSION_PIN_ENTRY_TYPE, SESSION_PIN_ENV, SchedulerOptions, SchedulerSettings, SchedulerSettingsPatch, SelectionBias, SelectionPolicy, type ServiceAnnouncementHandle, type SessionPin, type SessionPinHost, UnknownAccountError, UnknownProviderError, VIRTUAL_ID_SEPARATOR, VirtualBackend, type VirtualIntegrationOptions, VirtualModelConfig, VirtualModelTemplate, VirtualProviderConfig, type VirtualProviderDependencies, applySessionPins, captureVirtualModelTemplate, createManagedIntegration, createServiceAnnouncement, createVirtualIntegrations, createVirtualProvider, getMultiAuthPath, healVirtualTemplates, inheritedSessionPinsFromEnv, inheritedSessionPinsFromUnknown, liftProvider, mergeProviderAuth, normalizeUpstreamPreferences, registerMultiProvider, serializeInheritedSessionPins, sessionPinsFromEntries, virtualBackendAccountId, virtualSchedulerId };